#import code tools, otherwise computer has no idea what clock or set_caption is
import pygame

#tools only sitting there, need to use them
pygame.init()

#Set window size/title
gameDisplay = pygame.display.set_mode((800,600))
pygame.display.set_caption('Crashing Game')

#every app needs to run certain number of times per second (FPS)
clock = pygame.time.Clock()

#crashed has no meaning or use until we use it in the if statement
crashed = False

#while runs code inside as long as it is true
#"not false" means true
#setting crashed = true makes the while loop false, stopping it
while not crashed:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            crashed = True

        print(event)

    pygame.display.update()
    clock.tick(60)
#computer read code from top to bottom, stuck running the while loop while
#it is true
pygame.quit()
quit()
