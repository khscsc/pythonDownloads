{\rtf1\ansi\ansicpg1252\cocoartf1561\cocoasubrtf200
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 import pygame\
\
pygame.init()\
\
window_width = 800\
window_height = 600\
\
black = (0,0,0)\
white = (255,255,255)\
\
gameDisplay = pygame.display.set_mode((window_width,window_height))\
pygame.display.set_caption('Crashing Game')\
\
car_image = pygame.image.load('car.png')\
\
def car(x,y):\
    gameDisplay.blit(pygame.transform.scale(car_image, (200, 100)), (x,y))\
    \
x = (window_width * 0.5)\
y = (window_height * 0.5)\
\
x_change = 0\
car_speed = 0\
\
clock = pygame.time.Clock()\
\
crashed = False\
\
while not crashed:\
    for event in pygame.event.get():\
        if event.type == pygame.QUIT:\
            crashed = True\
\
        ############################\
        if event.type == pygame.KEYDOWN:\
            if event.key == pygame.K_LEFT:\
                x_change = -5\
            elif event.key == pygame.K_RIGHT:\
                x_change = 5\
        if event.type == pygame.KEYUP:\
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:\
                x_change = 0\
        ######################\
    ##\
    x += x_change\
   ##         \
    gameDisplay.fill(white)\
    car(x,y)\
        \
    pygame.display.update()\
    clock.tick(60)\
\
pygame.quit()\
quit()\
}