import pygame

pygame.init()

#dimensions declared using variables
window_width = 800
window_height = 600

#black and white mean nothing until we use them
black = (0,0,0)
white = (255,255,255)

#declare window resolution
gameDisplay = pygame.display.set_mode((window_width,window_height))
pygame.display.set_caption('Crashing Game')

#car import and displaying
#blit is a tool of pygame - it draws things onto your screen
#.blit('image', (coordinates))
car_image = pygame.image.load('car.png')

def car(x,y):
    gameDisplay.blit(pygame.transform.scale(car_image, (200, 100)), (x,y))
    
#position of car will be declared here
x = (window_width * 0.5)
y = (window_height * 0.5)

clock = pygame.time.Clock()

crashed = False

while not crashed:
    gameDisplay.fill(black)
    car(x,y)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            crashed = True

        print(event)

    pygame.display.update()
    clock.tick(60)

pygame.quit()
quit()
